Create Database Telcomundo;
Use Telcomundo;


Create Table Clientes(
cliente_unico tinyint unsigned auto_increment,
Nombre varchar(20),
documento int,
direccion varchar (40),
saldo int,
limite_de_credito varchar(60),
descuento int,
primary key(cliente_unico));


Create Table Articulos(
articulo_unico tinyint unsigned auto_increment,
Nombre varchar(30),
precio decimal(5,2)
);

Create table pedidos(
numero_de_cliente int,
Nombre varchar(20),
direccion varchar(30),
fecha_del_pedido date,
telefono char(40),
primary key(numero_de_cliente));

Create table distribuidores(
numero_de_fabrica int,
telefono varchar(60),
cantidad_de_articulos varchar(60),
fabrica_externas int,
primary key(numero_de_fabrica));

insert into Clientes(nombre,documento,direccion,saldo,limite_de_credito,descuento) values
('Juan Rodriguez',1222345,'carr 4 # 20-52',1500,'60 dias',500);
insert into Clientes(nombre,documento,direccion,saldo,limite_de_credito,descuento) values
('luis lopez',1232345,'call 6 # 40-59',3500,'90 dias',800);
insert into Clientes(nombre,documento,direccion,saldo,limite_de_credito,descuento) values
('ana Rodriguez',1222344,'carr 8 # 50-53',1600,'120 dias',400);
insert into Clientes(nombre,documento,direccion,saldo,limite_de_credito,descuento) values
('luisa gomez',2222345,'carr 14 # 60-52',5500,'80 dias',900);
insert into Clientes(nombre,documento,direccion,saldo,limite_de_credito,descuento) values
('Julian Rozo',1222345,'call 44 # 60-82',6500,'180 dias',700);
insert into Clientes(nombre,documento,direccion,saldo,limite_de_credito,descuento) values
('German Sicard',3222345,'carr 45 # 60-22',7500,'320 dias',200);
insert into Clientes(nombre,documento,direccion,saldo,limite_de_credito,descuento) values
('ivan Rodriguez',6222345,'call 54 # 70-32',11500,'360 dias',800);
insert into Clientes(nombre,documento,direccion,saldo,limite_de_credito,descuento) values
('andrea Rodriguez',6222345,'carr 46 # 90-22',61500,'310 dias',100);

insert into Articulos(nombre,precio) values
('andrea Rodriguez',6222345,'carr 46 # 90-22',61500,'310 dias',100);



select * from Clientes;
show tables;
describe Clientes;
describe Articulos;
describe pedidos;
describe distribuidores;

