<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="02inicio.css">
    <title>Ventas</title>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css"
          integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" 
          crossorigin="anonymous" referrerpolicy="no-referrer" />
 
</head>
<body>
    <i class="fa-solid fa-user"></i>
    <h2>BIENVENIDO USUARIO</h2>
    <a href="01Login.php">Salir</a>
    <a href="14buscar.php">Actualizar datos</a>
    <div id="header">
        <ul class="nav">
            <li><a href="">Ventas</a>
                <ul>
                </ul>
            </li>
            <li><a href="">Asesores</a>
                <ul>
                    <li><a href="07Historicoventas.php">Historico De Ventas</a></li>
                </ul>
            </li>
            <li><a href="https://tienda.claro.com.co">Producto</a></li>
            <li><a href="">Lider</a>
                <ul>
                    <li><a href="Eliminarorden.html">Eliminar Orden de trabajo</a></li>
                    <li><a href="Buscarorden.html">Buscar orden de trabajo</a></li>
                    <li><a href="Eliminarusuario.html">Eliminar usuario</a></li>
                    <li><a href="Buscarusuario.html">Buscar usuario</a></li>
                </ul>
            </li>
        </ul>



    </div>
        <div class="Ofertas">
            <li><a href="https://www2.claro.com.co/personas/servicios/promociones/">Nuevas Ofertas</a></li>
				<li><a href="https://www.youtube.com/watch?v=N0389X9kw7Y">Capacitaciones</a></li>
        </div>
</body>
</html>