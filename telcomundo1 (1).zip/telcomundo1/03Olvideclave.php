<?php
if($_REQUEST['ID'] ==null && $_REQUEST['contraseña'] ==null)
{
    echo "
    <script>alert('Ingrese datos al formulario');
                window.location = 'Actualizarcontraseña.php';    
            </script>
        ";
}elseif ($_REQUEST['ID']!==null && $_REQUEST['contraseña'] ==null){
    echo "
        <script>alert('Datos Incorrectos');
                    window.location = '1Login.php';    
                </script>
            ";
    }
    elseif ($_REQUEST['ID']==null && $_REQUEST['contraseña']!==null){
        echo "
        <script>alert('Contraseña Incorrecta');
                    window.location = '01Login.php';    
                </script>
            ";
        }
  else {
   
    include 'Conexion.php';
    $colsulta = mysqli_query($colsulta, "select * from usuario where id_usuario=$id")
    or die("Problemas en el select:" . mysqli_error($conecta));
    if ($reg = mysqli_fetch_array($conecta)) { 
        header("location: actualizar.php");
    }
    if ($colsulta== true){
        echo "
        <script>alert('USUARIO O CONTRASEÑA INCORRECTA');
                    window.location = '01Login.php';    
                </script>
            ";
    
    }



    mysqli_close($conecta);
   

  }



  ?>

