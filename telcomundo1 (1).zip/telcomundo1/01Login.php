<?php 
session_start();
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
  header("location: 02inicio.php");
  exit;
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Login Form Design One | Fazt</title>
    <link rel="stylesheet" href="01Login.css">
  </head>
  <body>

    <div class="Login">
      <img src="t.png" class="avatar" alt="Avatar Image">
      <h1>TELCOMUNDO</h1>
      <form method=POST ACTION=iniciosesion.php>
        <label for="username">ID USUARIO</label>
        <input type="text" placeholder="INGRESA TU ID"name="ID">
        <label for="password">Contraseña</label>
        <input type="password" placeholder="Ingresa tu contraseña"name="contraseña">
        <input type="submit" name="botton">
        <a href="03Olvideclave.php">Olvidaste la contraseña</a><br>
        <a href="04Registro.html">Registrate</a>
      </form>
    </div>
  </body>

  
</html>