<html>
<head>
     <title>Usuario Eliminado</title>
     <link href="formulario1.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <?php
    include 'Conexion.php';
    $registros = mysqli_query($conecta, "select id_usuario from Usuario where 
    id_usuario=$_REQUEST[id_usuario]") or
    die("Problemas en el select:" .
    mysqli_error($conecta));
    if ($reg = mysqli_fetch_array($registros)) {
    mysqli_query($conecta, "delete from Usuario
    where id_usuario=$_REQUEST[id_usuario]") or
    die("Problemas en el select:" .
    mysqli_error($conecta));
    echo "Se efectuó el borrado del usuario con el 
    codigo digitado.";
    } else {
    echo "No existe un Usuario con ese codigo lo 
    siento intente con otro.";
    }
    mysqli_close($conecta);
    ?>
</body>

</html>