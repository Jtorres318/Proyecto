
<?php
if(isset($_POST['actualizar'])){
    include 'Conexion.php';
    $registros = mysqli_query($conecta, "UPDATE usuario 
    SET id_usuario =$_REQUEST[id_usuario],nombre ='$_REQUEST[nombre]',
    apellido='$_REQUEST[apellido]',correo='$_REQUEST[correo]',
    tel =$_REQUEST[tel]
    Where id_usuario=$_REQUEST[id_usuario] ") 
    or die("Problemas en el select:" . mysqli_error($conecta));

        if($registros ==TRUE){
        echo"<script>alert('actualizacion fue correcta');
                    window.location = '14actualizardatos.php';    
                </script>
            ";  
            }else{
                 echo"<script>alert('actualizacion incorrecta');
                    window.location = '14actualizardatos.php';    
                </script>";     
                 }


}

?>