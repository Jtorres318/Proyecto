﻿<?php
$usuario=$_POST['usuario'];
$contraseña=$_POS¨T['contraseña'];
session_star();

$conexion = mysqli_connect("localhost:3306","root", "", "telcomundo") or die("Problemas con la conexión");
$consulta="SELECT * FROM usuarios where usuario='$usuario' and contraseña='$contraseña'";

$filas=mysqli_fetch_array]($resultado);

if($filas['id_rol']==1){//lider
    header("location:
}else
if($filas['id_rol']==2){



else(
    ?>
    <?php
    include("");
    <h1 class="bad">ERROR EN LA AUTENTIFICACION</h1>
    <?php
}
mysql_free_result($resultado);
mysql_close($conexion)
