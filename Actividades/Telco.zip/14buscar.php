<html>
<head>
<title>Problema</title>
</head>
<body>
    <form action='14actualizardatos.php' method="POST">
        Ingrese usuario a buscar
        <input type="number"name="codigo">
        <br>
        <input type="submit"value="buscar ">
    </form>
</body>
</html>
