<?php
if($_REQUEST['ID'] ==null && $_REQUEST['contraseña'] ==null)
{
    echo "
    <script>alert('Ingrese datos al formulario');
                window.location = '14actualizardatos.php';    
            </script>
        ";
}elseif ($_REQUEST['ID']!==null && $_REQUEST['contraseña'] ==null){
    echo "
        <script>alert('Datos Incorrectos');
                    window.location = '1Login.php';    
                </script>
            ";
    }
    elseif ($_REQUEST['ID']==null && $_REQUEST['contraseña']!==null){
        echo "
        <script>alert('Contraseña Incorrecta');
                    window.location = '01Login.php';    
                </script>
            ";
        }
  else {
    $conexion = mysqli_connect("localhost:3306","root", "", "telcomundo") or die("Problemas con la conexión");
    
    $colsulta = mysqli_query($colsulta, "select * from usuario where id_usuario=$id")
    or die("Problemas en el select:" . mysqli_error($conexion));
    if ($reg = mysqli_fetch_array($conexion)) { 
        header("location: actualizar.php");
    }
    if ($colsulta== true){
        echo "
        <script>alert('USUARIO O CONTRASEÑA INCORRECTA');
                    window.location = '01Login.php';    
                </script>
            ";
    
    }



    mysqli_close($conexion);
   

  }



  ?>

