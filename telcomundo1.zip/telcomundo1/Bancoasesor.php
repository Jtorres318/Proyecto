
<html>
<html>
<head>
<title>Pagina 2 en PHP para la conexion
con el Codigo de MYSQL </title>
</head>
<body>
<?php

   $conexion = mysqli_connect("localhost:3306","root", "", "telcomundo") or die("Problemas con la conexión");
    $colsulta= mysqli_query($conexion,"insert into banco_asesor(id_asesor,banco,numero_cuenta) 
    values($_REQUEST[id_asesor],'$_REQUEST[banco]',$_REQUEST[numero_cuenta])") 
    or die("Problemas en el select".mysqli_error($conexion));
    mysqli_close($conexion);
    echo '<script language="javascript">alert("La venta fue registrada");
                window.location = "02inicio3asesor.php"; 
</script>';


?>
</body>
</html>