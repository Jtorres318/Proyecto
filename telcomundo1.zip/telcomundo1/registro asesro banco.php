<?php
$conexion = mysqli_connect("localhost:3306","root", "", "telcomundo") or die("Problemas con la conexión");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
	<link href="formulario1.css" rel="stylesheet" type="text/css" />
	<link href="formulario2.css" rel="stylesheet" type="text/css" />
	<link href="formulario3.css" rel="stylesheet" type="text/css" />
    <title>REGISTRAR VENTAS</title>
</head>
<body>
<header>
      <nav>
        <a class="ultimos" href="02inicio.html">Regresar</a>
      </nav>
    </header>
    <main>
      <h1>REGISTRAR BANCO ASESOR</h1>
      <div class="Login">
    <form action="Bancoasesor.php" method="post">
            
        <div class='field'>
            <input type="number" name="id_asesor" size="40" placeholder="id_usuario">
        </div>
        <div class='field'>
            <input type="text" name="banco" size="40" placeholder="banco">
        </div>
        <div class='field'>
            <input type="number" name="numero_cuenta" size="20" placeholder="numero_Cuenta">
        </div>
        
        <div class='submit'>
          <button>
            REGISTRAR
          </button>

      </form>
      </div>
    
    
                
                
       
      
 </table>
</body>
</html>