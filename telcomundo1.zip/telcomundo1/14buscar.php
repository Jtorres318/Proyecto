<html>
<head>
<title>Problema</title>
<head> <link href='formulario1.css' rel='stylesheet' type='text/css' />
	
</head>
<body>
 <h1>BIENVENIDO A TELCOMUNDO</h1>
    
    <form action='14actualizardatos.php' method="POST">
       <h3> Ingrese usuario a buscar</h3> 
        <input type="number"name="codigo">
        <br>
        <input type="submit"value="buscar ">
    </form>
</body>
</html>
