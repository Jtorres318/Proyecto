<html>
<head>
     <title>Orden borrada</title>
     <link href="formulario1.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <?php
    $conexion = mysqli_connect("localhost:3306","root","","telcomundo") or
    die("Problemas con la conexión");
    $registros = mysqli_query($conexion, "select orden_trabajo from Informe_ventas where 
    orden_trabajo=$_REQUEST[orden_trabajo]") or
    die("Problemas en el select:" .
    mysqli_error($conexion));
    if ($reg = mysqli_fetch_array($registros)) {
    mysqli_query($conexion, "delete from Informe_ventas
    where orden_trabajo=$_REQUEST[orden_trabajo]") or
    die("Problemas en el select:" .
    mysqli_error($conexion));
    echo "<script>alert('ORDEN  ELIMINADA');
             window.location = 'O2inicio1lider';    
                </script>
            ";  

    } else {
    echo "<script>alert('no se elimino orden intente de nuevo');
                    window.location = 'Eliminarorden.html';    
                </script>
            ";  

    }
    mysqli_close($conexion);
    ?>
</body>

</html>